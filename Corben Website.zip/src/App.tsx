import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import Landing from './pages/Landing';
import About from './pages/About';

function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'about'>('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.slice(1);
      setCurrentPage(hash === 'about' ? 'about' : 'home');
      setMobileMenuOpen(false);
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigateTo = (page: 'home' | 'about') => {
    window.location.hash = page === 'home' ? '' : page;
    setMobileMenuOpen(false);
  };

  return (
    <>
      {currentPage !== 'home' && (
        <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-sm z-50 border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              <button
                onClick={() => navigateTo('home')}
                className="text-2xl font-black tracking-tighter text-black"
              >
                CORBY CUTS
              </button>

              {/* Mobile menu toggle only */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden text-black"
                aria-label="Toggle menu"
              >
                {mobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
            </div>
          </div>
        </nav>
      )}

      <div className={currentPage !== 'home' ? 'pt-[73px]' : ''}>
        {currentPage === 'home' ? <Landing /> : <About />}
      </div>
    </>
  );
}

export default App;

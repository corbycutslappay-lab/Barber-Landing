export function InstagramLogo({ className = 'w-6 h-6' }: { className?: string }) {
  return (
    <img
      src="https://is1-ssl.mzstatic.com/image/thumb/PurpleSource221/v4/e4/ae/a5/e4aea589-149a-f54a-c58b-54241c0d8634/Placeholder.mill/200x200bb-75.webp"
      alt="Instagram"
      className={className}
    />
  );
}

export function TikTokLogo({ className = 'w-6 h-6' }: { className?: string }) {
  return (
    <img
      src="https://is1-ssl.mzstatic.com/image/thumb/PurpleSource221/v4/4c/40/f7/4c40f7fc-d9d9-c382-8805-cd868ea2258e/Placeholder.mill/200x200bb-75.webp"
      alt="TikTok"
      className={className}
    />
  );
}

export function YoutubeLogo({ className = 'w-6 h-6' }: { className?: string }) {
  return (
    <img
      src="https://is1-ssl.mzstatic.com/image/thumb/PurpleSource221/v4/2b/4e/7a/2b4e7a58-540d-268e-4531-c8b7d60150bd/Placeholder.mill/200x200bb-75.webp"
      alt="YouTube"
      className={className}
    />
  );
}

export function SnapchatLogo({ className = 'w-6 h-6' }: { className?: string }) {
  return (
    <img
      src="https://is1-ssl.mzstatic.com/image/thumb/PurpleSource221/v4/d7/f4/2a/d7f42a26-b968-5b0a-3f3e-3fb6bf4e6149/Placeholder.mill/200x200bb-75.webp"
      alt="Snapchat"
      className={className}
    />
  );
}

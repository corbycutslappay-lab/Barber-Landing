import { useState, useEffect } from 'react';
import { Mail } from 'lucide-react';
import {
  InstagramLogo,
  TikTokLogo,
  YoutubeLogo,
  SnapchatLogo,
} from '../components/SocialLogos';
import { supabase } from '../lib/supabase';
import { BarberProfile } from '../types/database';

export default function About() {
  const [profile, setProfile] = useState<BarberProfile | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const { data: profileData } = await supabase
      .from('barber_profile')
      .select('*')
      .maybeSingle();

    if (profileData) setProfile(profileData);
  };

  if (!profile) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-black">Loading...</div>
      </div>
    );
  }

  const aboutMeDescription =
    "I'm a Filipino barber currently in high school, focused on delivering clean, precise cuts that help people feel confident. I'm always learning and sharpening my skills to improve with every client. Everyone is welcome in my chair, and my goal is to make sure you leave looking sharp and feeling confident.";

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-6 py-16 lg:py-20">
        {/* About Me Section */}
        <div className="space-y-8 lg:space-y-12 mb-12 lg:mb-16">
          <h1 className="text-5xl lg:text-6xl font-black tracking-tighter text-black uppercase">
            About Me
          </h1>

          <div className="flex flex-col lg:flex-row gap-6 lg:gap-8 items-start">
            {/* Profile Picture */}
            <div className="relative flex-shrink-0">
              <div className="w-40 h-40 lg:w-56 lg:h-56 rounded-full bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-600 p-2">
                <div className="w-full h-full rounded-full bg-white p-2">
                  <img
                    src="/corby_cuts_profle_picture.jpg"
                    alt="Corby Cuts Profile"
                    className="w-full h-full rounded-full object-cover"
                  />
                </div>
              </div>
            </div>

            {/* About Text */}
            <div className="flex-1">
              <p className="text-xl lg:text-2xl leading-snug text-gray-700 h-[224px] lg:h-[224px]">
                {aboutMeDescription}
              </p>
            </div>
          </div>

          {/* Stats Section */}
          <div className="grid grid-cols-2 gap-6 max-w-md">
            <div className="border-3 border-black p-6 rounded-lg">
              <div className="text-4xl font-black text-black mb-2">#1</div>
              <div className="text-xs font-black text-black uppercase tracking-wide">
                Local Barber
              </div>
            </div>

            <div className="border-3 border-black p-6 rounded-lg">
              <div className="text-4xl font-black text-black mb-2">1K+</div>
              <div className="text-xs font-black text-black uppercase tracking-wide">
                Clients Served
              </div>
            </div>
          </div>
        </div>

        {/* Specialties Section */}
        <div className="space-y-6">
          <h2 className="text-3xl font-black text-black mb-4 uppercase">
            Specialties
          </h2>
          <div className="flex flex-wrap gap-3 mb-6">
            {profile.specialties.map((specialty, index) => (
              <span
                key={index}
                className="px-4 py-2 bg-black text-white text-sm font-black rounded-lg uppercase"
              >
                {specialty}
              </span>
            ))}
          </div>

          {/* Contact / Schedule / Socials Section */}
          <div className="space-y-6">
            <div className="space-y-3">
              <h2 className="text-2xl font-bold text-black">Contact</h2>
              <a
                href={`mailto:${profile.email}`}
                className="flex items-center gap-3 text-gray-700 hover:text-black transition-colors"
              >
                <Mail className="w-5 h-5" />
                <span>{profile.email}</span>
              </a>
            </div>

            <a
              href={profile.calendly_url}
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full bg-gradient-to-r from-black to-gray-800 hover:from-gray-900 hover:to-black text-white text-center py-4 px-6 font-black rounded-xl hover:shadow-2xl transition-all transform hover:scale-[1.05] active:scale-[0.95] uppercase shadow-lg"
            >
              Schedule Now
            </a>

            <div className="flex gap-4 justify-start">
              <a
                href={profile.instagram_url}
                target="_blank"
                rel="noopener noreferrer"
                className="transition-all transform hover:scale-125 duration-200"
                aria-label="Instagram"
              >
                <InstagramLogo className="w-10 h-10" />
              </a>
              <a
                href={profile.tiktok_url}
                target="_blank"
                rel="noopener noreferrer"
                className="transition-all transform hover:scale-125 duration-200"
                aria-label="TikTok"
              >
                <TikTokLogo className="w-8 h-8" />
              </a>
              <a
                href={profile.youtube_url}
                target="_blank"
                rel="noopener noreferrer"
                className="transition-all transform hover:scale-125 duration-200"
                aria-label="YouTube"
              >
                <YoutubeLogo className="w-8 h-8" />
              </a>
              <a
                href={profile.snapchat_url}
                target="_blank"
                rel="noopener noreferrer"
                className="transition-all transform hover:scale-125 duration-200"
                aria-label="Snapchat"
              >
                <SnapchatLogo className="w-8 h-8" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

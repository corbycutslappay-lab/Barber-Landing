import { useState, useEffect } from 'react';
import Carousel from '../components/Carousel';
import {
  InstagramLogo,
  TikTokLogo,
  YoutubeLogo,
  SnapchatLogo,
} from '../components/SocialLogos';
import { supabase } from '../lib/supabase';
import { BarberProfile, CarouselMedia } from '../types/database';

export default function Landing() {
  const [profile, setProfile] = useState<BarberProfile | null>(null);
  const [carouselMedia, setCarouselMedia] = useState<CarouselMedia[]>([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const { data: profileData } = await supabase
      .from('barber_profile')
      .select('*')
      .maybeSingle();

    const { data: mediaData } = await supabase
      .from('carousel_media')
      .select('*')
      .order('display_order');

    if (profileData) setProfile(profileData);

    // ✅ ONLY KEEP FIRST 3 CAROUSEL ITEMS
    if (mediaData) setCarouselMedia(mediaData.slice(0, 3));
  };

  if (!profile) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-black">Loading...</div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-white flex flex-col lg:flex-row overflow-hidden">
      <div className="w-full lg:w-1/2 h-[50vh] lg:h-screen">
        <Carousel media={carouselMedia} />
      </div>

      <div className="w-full lg:w-1/2 h-[50vh] lg:h-screen flex items-center justify-center p-6 lg:p-16 overflow-y-auto lg:overflow-y-hidden">
        <div className="max-w-lg w-full space-y-6 lg:space-y-8">
          <div className="space-y-2 lg:space-y-3">
            <h1 className="text-5xl lg:text-8xl font-black tracking-tighter text-black leading-none uppercase">
              {profile.name}
            </h1>
            <p className="text-lg lg:text-3xl font-bold text-black tracking-tight">
              {profile.tagline}
            </p>
          </div>

          <div className="flex gap-5 pt-2">
            <a
              href={profile.instagram_url}
              target="_blank"
              rel="noopener noreferrer"
              className="transition-all transform hover:scale-125 duration-200"
              aria-label="Instagram"
            >
              <InstagramLogo className="w-7 h-7" />
            </a>
            <a
              href={profile.tiktok_url}
              target="_blank"
              rel="noopener noreferrer"
              className="transition-all transform hover:scale-125 duration-200"
              aria-label="TikTok"
            >
              <TikTokLogo className="w-7 h-7" />
            </a>
            <a
              href={profile.youtube_url}
              target="_blank"
              rel="noopener noreferrer"
              className="transition-all transform hover:scale-125 duration-200"
              aria-label="YouTube"
            >
              <YoutubeLogo className="w-7 h-7" />
            </a>
            <a
              href={profile.snapchat_url}
              target="_blank"
              rel="noopener noreferrer"
              className="transition-all transform hover:scale-125 duration-200"
              aria-label="Snapchat"
            >
              <SnapchatLogo className="w-7 h-7" />
            </a>
          </div>

          <div className="space-y-3 pt-2 lg:pt-4">
            <a
              href={profile.calendly_url}
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full bg-gradient-to-r from-black to-gray-800 hover:from-gray-900 hover:to-black text-white text-center py-4 lg:py-5 px-6 lg:px-8 text-base lg:text-xl font-black tracking-tight rounded-xl hover:shadow-2xl transition-all transform hover:scale-[1.05] active:scale-[0.95] uppercase shadow-lg"
            >
              Book Appointment
            </a>
            <button
              onClick={() => (window.location.hash = 'about')}
              className="block w-full border-3 border-black text-black text-center py-3 lg:py-4 px-6 lg:px-8 text-base lg:text-lg font-black tracking-tight rounded-lg hover:bg-black hover:text-white transition-all transform hover:scale-[1.02] active:scale-[0.98] uppercase"
            >
              View About Me
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

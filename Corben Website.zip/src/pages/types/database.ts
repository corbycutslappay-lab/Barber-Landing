export interface BarberProfile {
  id: string;
  name: string;
  tagline: string;
  bio: string;
  years_experience: number;
  specialties: string[];
  phone: string;
  email: string;
  instagram_url: string;
  tiktok_url: string;
  youtube_url: string;
  snapchat_url: string;
  calendly_url: string;
  created_at: string;
  updated_at: string;
}

export interface CarouselMedia {
  id: string;
  image_url: string;
  title: string;
  display_order: number;
  created_at: string;
}

export interface PortfolioItem {
  id: string;
  image_url: string;
  title: string;
  description: string;
  category: string;
  instagram_url?: string;
  display_order: number;
  created_at: string;
}

/*
  # Add Instagram URL field to portfolio items

  1. Changes
    - Add `instagram_url` column to `portfolio_items` table to store Instagram post/reel links
    - This allows portfolio items to link directly to their Instagram source
  
  2. Notes
    - Column is nullable to support items that may not have Instagram links
    - No default value as it's optional
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'portfolio_items' AND column_name = 'instagram_url'
  ) THEN
    ALTER TABLE portfolio_items ADD COLUMN instagram_url text;
  END IF;
END $$;

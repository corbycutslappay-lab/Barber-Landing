/*
  # Barber Portfolio Database Schema

  ## Overview
  Creates tables for a professional barber portfolio website with landing page carousel,
  barber profile information, and portfolio gallery.

  ## New Tables
  
  ### `barber_profile`
  - `id` (uuid, primary key) - Unique identifier
  - `name` (text) - Barber's display name
  - `tagline` (text) - Hero section tagline
  - `bio` (text) - Detailed biography
  - `years_experience` (integer) - Years in the industry
  - `specialties` (text array) - List of specialties
  - `phone` (text) - Contact phone number
  - `email` (text) - Contact email
  - `instagram_url` (text) - Instagram profile link
  - `tiktok_url` (text) - TikTok profile link
  - `youtube_url` (text) - YouTube channel link
  - `calendly_url` (text) - Calendly scheduling link
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### `carousel_media`
  - `id` (uuid, primary key) - Unique identifier
  - `image_url` (text) - URL to carousel image
  - `title` (text) - Optional image title
  - `display_order` (integer) - Order in carousel sequence
  - `created_at` (timestamptz) - Record creation timestamp

  ### `portfolio_items`
  - `id` (uuid, primary key) - Unique identifier
  - `image_url` (text) - URL to portfolio image
  - `title` (text) - Haircut/style title
  - `description` (text) - Description of the work
  - `category` (text) - Category for filtering (e.g., 'fade', 'design', 'beard', 'color')
  - `display_order` (integer) - Order in portfolio
  - `created_at` (timestamptz) - Record creation timestamp

  ## Security
  - Enable RLS on all tables
  - Add public read access policies for all tables (public portfolio website)
*/

-- Create barber_profile table
CREATE TABLE IF NOT EXISTS barber_profile (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT 'Corby Cuts',
  tagline text NOT NULL DEFAULT 'Premium Cuts. Bold Style.',
  bio text NOT NULL DEFAULT '',
  years_experience integer DEFAULT 0,
  specialties text[] DEFAULT '{}',
  phone text DEFAULT '',
  email text DEFAULT '',
  instagram_url text DEFAULT '',
  tiktok_url text DEFAULT '',
  youtube_url text DEFAULT '',
  calendly_url text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create carousel_media table
CREATE TABLE IF NOT EXISTS carousel_media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  image_url text NOT NULL,
  title text DEFAULT '',
  display_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create portfolio_items table
CREATE TABLE IF NOT EXISTS portfolio_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  image_url text NOT NULL,
  title text NOT NULL,
  description text DEFAULT '',
  category text NOT NULL,
  display_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE barber_profile ENABLE ROW LEVEL SECURITY;
ALTER TABLE carousel_media ENABLE ROW LEVEL SECURITY;
ALTER TABLE portfolio_items ENABLE ROW LEVEL SECURITY;

-- Public read access policies
CREATE POLICY "Public can view barber profile"
  ON barber_profile FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Public can view carousel media"
  ON carousel_media FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Public can view portfolio items"
  ON portfolio_items FOR SELECT
  TO anon, authenticated
  USING (true);
/*
  # Update Barber Content and Portfolio

  ## Changes
  - Update barber profile with new bio and links
  - Add Snapchat URL column
  - Recreate portfolio items with new categories (Straight Hair, Wavy Hair, Curly Hair)
  - Remove phone display but keep in database for internal use
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'barber_profile' AND column_name = 'snapchat_url'
  ) THEN
    ALTER TABLE barber_profile ADD COLUMN snapchat_url text DEFAULT '';
  END IF;
END $$;

DELETE FROM portfolio_items;

INSERT INTO portfolio_items (image_url, title, description, category, display_order) VALUES
('https://images.pexels.com/photos/1805600/pexels-photo-1805600.jpeg?auto=compress&cs=tinysrgb&w=800', 'Clean Fade', 'Sharp straight hair fade with precision lines', 'Straight Hair', 1),
('https://images.pexels.com/photos/1570806/pexels-photo-1570806.jpeg?auto=compress&cs=tinysrgb&w=800', 'Textured Top', 'Straight hair with textured top styling', 'Straight Hair', 2),
('https://images.pexels.com/photos/1803875/pexels-photo-1803875.jpeg?auto=compress&cs=tinysrgb&w=800', 'Line Design', 'Crisp line work on straight hair', 'Straight Hair', 3),
('https://images.pexels.com/photos/3998385/pexels-photo-3998385.jpeg?auto=compress&cs=tinysrgb&w=800', 'Wavy Flow', 'Smooth styling for wavy hair', 'Wavy Hair', 4),
('https://images.pexels.com/photos/1407322/pexels-photo-1407322.jpeg?auto=compress&cs=tinysrgb&w=800', 'Wave Pattern', 'Enhanced wave pattern cut', 'Wavy Hair', 5),
('https://images.pexels.com/photos/1757363/pexels-photo-1757363.jpeg?auto=compress&cs=tinysrgb&w=800', 'Wavy Fade', 'Low fade with wavy texture', 'Wavy Hair', 6),
('https://images.pexels.com/photos/1845534/pexels-photo-1845534.jpeg?auto=compress&cs=tinysrgb&w=800', 'Curly Top', 'Defined curls with clean edges', 'Curly Hair', 7),
('https://images.pexels.com/photos/1848236/pexels-photo-1848236.jpeg?auto=compress&cs=tinysrgb&w=800', 'Curl Definition', 'Enhanced curl definition and shape', 'Curly Hair', 8),
('https://images.pexels.com/photos/1661471/pexels-photo-1661471.jpeg?auto=compress&cs=tinysrgb&w=800', 'Textured Curls', 'Textured curly hair cut', 'Curly Hair', 9);

UPDATE barber_profile SET
  bio = 'I''m a Filipino barber currently in high school, focused on delivering clean, precise cuts that help people feel confident. I''m always learning and sharpening my skills to improve with every client. Everyone is welcome in my chair, and my goal is to make sure you leave looking sharp and feeling confident.',
  specialties = ARRAY['Designs', 'Shear Work', 'Fades'],
  instagram_url = 'https://www.instagram.com/corby_cuts',
  tiktok_url = 'https://www.tiktok.com/@corbycuts',
  youtube_url = 'https://youtube.com/@corbycuts',
  snapchat_url = 'https://www.snapchat.com/add/corbycuts',
  email = 'corbycutslappay@gmail.com',
  calendly_url = 'https://calendly.com/corbycutslappay/haircut';